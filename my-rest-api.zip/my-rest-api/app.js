const express = require('express');
const {exec} = require("child_process");
const app = express();

const port = 3000;

app.get('/', (req, res) => {
  res.send('Hello, World!');
});

app.get('/triggerw-bat', (req, res) => {
  
    const batFilePath = 'restapi_test.bat';
  
    exec(batFilePath, (error, stdout, stderr) => {
      console.log(`stdout: ${stdout}`);
      console.error(`stderr: ${stderr}`);
      console.log(error)
      if (error) {
        console.error(`Error executing the .bat file: ${error}`);
        return res.status(500).send('Internal Server Error');
      }
      res.send('BAT file executed successfully');
    });
  });

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});